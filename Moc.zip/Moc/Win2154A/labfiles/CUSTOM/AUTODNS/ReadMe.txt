The files in this folder are used for customization. Running the dnssuf.vbs script will configure the student computers as they would be after successful completion of the DNS LAb in Mdule 2.

Copy the Autodns folder to the C drive on the student computers and then run dnssuf.vbs.

