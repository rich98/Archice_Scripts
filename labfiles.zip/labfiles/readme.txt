GROUP POLICY SCENARIOS READ ME FILE
________________________________________________________________

TABLE OF CONTENTS

1. USING GROUP POLICY SCENARIOS
2. REQUIREMENTS
3. REMOVING GROUP POLICY SCENARIOS
3. KNOWN ISSUES
________________________________________________________________


1. USING GROUP POLICY SCENARIOS
   ----------------------------

Running the accompanying script file, will install the Group Policy objects (GPO) for each of the six scenarios onto the Domain that the machine is currently logged onto. The Group Policies will not be linked to any Organizational Unit, and can be found under the �All� tab when selecting Add Group Policy.

For information how to run the script file, see �GP Scenarios� whitepaper. Select �Start Menu->Programs->Group Policy Scenarios->GP Scenarios Whitepaper� to open the whitepaper.


2. REQUIREMENTS
   ------------

You must have sufficient rights to create policies in the domain. 

Following utilities are required to install the Policies: 

� NLTest
NLTest can be found in the Support\Tools Directory on the Windows 2000 Server CD. Run the MSI file to install NLTest or alternatively, expand NLTest from the CAB file to the same directory as the Group Policy Scenarios or to %Systemroot%\System32.

� SED
SED is installed with Group Policy Scenarios. This utility can also be found in �Services for Unix�, which can be downloaded from http://www.microsoft.com/ntserver/nts/downloads/previews/ntsfu/sfusites.asp

� LDifde
Ldifde is installed on Windows 2000 Server in the %systemdir%\system32 and is NOT installed on Windows 2000 Professional. Copy Ldifde to the same directory as the Group Policy Scenarios or to %Systemroot%\System32.


3. REMOVING GROUP POLICY SCENARIOS
   -------------------------------

To delete the Group Policies from the Active Directory open the Group Policy Editor and select each GPO and click Delete � chose �Remove the link and delete the Group Policy Object permanently�. 

To remove the Group Policy Scenarios source files (including documentation), go to Add/Remove Programs and select Remove �Group Policy Scenarios�.

4. KNOWN ISSUES
   ------------

The Policies are created using hard coded GUIDS and the script will fail if the policies already have been created. To successfully run the Load Policies again, the existing policies must be deleted.

The security on the Group Policy Template (located in SysVol) will not be synchronised with the Group Policy Container. It will inherit the default filesystem security for SysVol and should work as expected. To update this, modify the security for the Group Policy Object (via the Active Directory Users and Computers Management Console) and the security will automatically be synchronised. 